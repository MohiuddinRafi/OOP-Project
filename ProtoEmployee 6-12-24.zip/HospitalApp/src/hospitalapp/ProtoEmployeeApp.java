/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalapp;

import javax.swing.JOptionPane;

/**
 *
 * @author peter
 */
public class ProtoEmployeeApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
 ProtoEmployeeGUI myGUI = new ProtoEmployeeGUI();
        myGUI.setVisible(true);
}
}

    
  

